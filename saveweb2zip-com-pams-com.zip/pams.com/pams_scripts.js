// ----------------------------------------
// Mouse-overs
// ----------------------------------------

function hiLite(imgName,imgObjName) {
	if (document.images) {
	document.images[imgName].src = eval(imgObjName + ".src");
	}}

// ----------------------------------------
// Open new window - no scrollbars, no resize
// ----------------------------------------

function openWin(url,name,w,h) {
      var att = "WIDTH="+ w +",HEIGHT="+ h +",TOOLBAR=NO,SCROLLBARS=NO,MENU=NO,STATUS=NO,RESIZABLE=NO,TOP=50,LEFT=200"
      window.open(url,name,att);
      }

// ----------------------------------------
// Open new window - scrollbars and resize
// ----------------------------------------

function openWinSB(url,name,w,h) {
      var att = "WIDTH="+ w +",HEIGHT="+ h +",TOOLBAR=NO,SCROLLBARS=YES,MENU=NO,STATUS=NO,RESIZABLE=YES,TOP=50,LEFT=200"
      window.open(url,name,att);
      }

// ----------------------------------------
// Creates table of menu navigation buttons
// Function passed as "urhere" indicates which button set to grey out
// ----------------------------------------

function navwrite(urhere,pagename,path2use) {

// If the path2use variable exists, it indicates the call is from the cgi-bin directory
// so adjust the pathway to the graphics files.  (For most pages the path2use parameter
// will be undefined, because it was added much later.)

//	if (path2use) {
//		path="../pams/"	
//	}
//	else {
//		path="../"	
//	}

// Pre-load images for rollovers

	if (document.images) {
	but_1a = new Image(80,26); but_1a.src = "pgfx/but1a.jpg";
	but_1b = new Image(80,26); but_1b.src = "pgfx/but1b.jpg";
	but_1c = new Image(80,26); but_1c.src = "pgfx/but1c.jpg";

	but_2a = new Image(80,26); but_2a.src = "pgfx/but2a.jpg";
	but_2b = new Image(80,26); but_2b.src = "pgfx/but2b.jpg";
	but_2c = new Image(80,26); but_2c.src = "pgfx/but2c.jpg";

	but_3a = new Image(80,26); but_3a.src = "pgfx/but3a.jpg";
	but_3b = new Image(80,26); but_3b.src = "pgfx/but3b.jpg";
	but_3c = new Image(80,26); but_3c.src = "pgfx/but3c.jpg";

	but_4a = new Image(80,26); but_4a.src = "pgfx/but4a.jpg";
	but_4b = new Image(80,26); but_4b.src = "pgfx/but4b.jpg";
	but_4c = new Image(80,26); but_4c.src = "pgfx/but4c.jpg";

	but_5a = new Image(80,26); but_5a.src = "pgfx/but5a.jpg";
	but_5b = new Image(80,26); but_5b.src = "pgfx/but5b.jpg";
	but_5c = new Image(80,26); but_5c.src = "pgfx/but5c.jpg";

	but_6a = new Image(80,26); but_6a.src = "pgfx/but6a.jpg";
	but_6b = new Image(80,26); but_6b.src = "pgfx/but6b.jpg";
	but_6c = new Image(80,26); but_6c.src = "pgfx/but6c.jpg";

	but_7a = new Image(80,26); but_7a.src = "pgfx/but7a.jpg";
	but_7b = new Image(80,26); but_7b.src = "pgfx/but7b.jpg";
	but_7c = new Image(80,26); but_7c.src = "pgfx/but7c.jpg";

	but_8a = new Image(80,26); but_8a.src = "pgfx/but8a.jpg";
	but_8b = new Image(80,26); but_8b.src = "pgfx/but8b.jpg";
	but_8c = new Image(80,26); but_8c.src = "pgfx/but8c.jpg";

	}

// Table for logo and page heading

	document.write("<TABLE WIDTH=640 BORDER=0 CELLPADDING=0 CELLSPACING=0>")
	document.write("<TR>")
	document.write("<TD><IMG SRC=\"pgfx/pamsheader_01.jpg\" WIDTH=135 HEIGHT=94></TD>")
	document.write("<TD><IMG SRC=\"pgfx/pamsheader_02.jpg\" WIDTH=30 HEIGHT=94></TD>")
	document.write("<TD><IMG SRC=\"" + pagename + "\" WIDTH=445 HEIGHT=94></TD>")
	document.write("<TD><IMG SRC=\"pgfx/pamsheader_04.jpg\" WIDTH=30 HEIGHT=94></TD>")
	document.write("</TR></TABLE>")

// Begin the table for buttons

	document.write("<TABLE WIDTH=640 BORDER=0 CELLPADDING=0 CELLSPACING=0>")
	document.write("<TR>")

// Item 1

	if (urhere==1) {
		document.write("<TD><IMG SRC=\"pgfx/but1d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"index.html\" onMouseOver=\"hiLite('MBut1','but_1b')\" onMouseDown=\"hiLite('MBut1','but_1c')\" onMouseUp=\"hiLite('MBut1','but_1b')\" onMouseOut=\"hiLite('MBut1','but_1a')\">")
		document.write("<IMG SRC=\"pgfx/but1a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut1\" ALT=\"PAMS Home Page\"></A></TD>")
	}

// Item 2

	if (urhere==2) {
		document.write("<TD><IMG SRC=\"pgfx/but2d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"history.html\" onMouseOver=\"hiLite('MBut2','but_2b')\" onMouseDown=\"hiLite('MBut2','but_2c')\" onMouseUp=\"hiLite('MBut2','but_2b')\" onMouseOut=\"hiLite('MBut2','but_2a')\">")
		document.write("<IMG SRC=\"pgfx/but2a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut2\" ALT=\"PAMS History\"></A></TD>")
	}

// Item 3

	if (urhere==3) {
		document.write("<TD><IMG SRC=\"pgfx/but3d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"listen.html\" onMouseOver=\"hiLite('MBut3','but_3b')\" onMouseDown=\"hiLite('MBut3','but_3c')\" onMouseUp=\"hiLite('MBut3','but_3b')\" onMouseOut=\"hiLite('MBut3','but_3a')\">")
		document.write("<IMG SRC=\"pgfx/but3a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut3\" ALT=\"Listen to PAMS\"></A></TD>")
	}

// Item 4

	if (urhere==4) {
		document.write("<TD><IMG SRC=\"pgfx/but4d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"services.html\" onMouseOver=\"hiLite('MBut4','but_4b')\" onMouseDown=\"hiLite('MBut4','but_4c')\" onMouseUp=\"hiLite('MBut4','but_4b')\" onMouseOut=\"hiLite('MBut4','but_4a')\">")
		document.write("<IMG SRC=\"pgfx/but4a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut4\" ALT=\"PAMS Services\"></A></TD>")
	}

// Item 5

	if (urhere==5) {
		document.write("<TD><IMG SRC=\"pgfx/but5d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"magic.html\" onMouseOver=\"hiLite('MBut5','but_5b')\" onMouseDown=\"hiLite('MBut5','but_5c')\" onMouseUp=\"hiLite('MBut5','but_5b')\" onMouseOut=\"hiLite('MBut5','but_5a')\">")
		document.write("<IMG SRC=\"pgfx/but5a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut5\" ALT=\"PAMS CD Collection\"></A></TD>")
	}

// Item 6

	if (urhere==6) {
		document.write("<TD><IMG SRC=\"pgfx/but6d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"photos1.html\" onMouseOver=\"hiLite('MBut6','but_6b')\" onMouseDown=\"hiLite('MBut6','but_6c')\" onMouseUp=\"hiLite('MBut6','but_6b')\" onMouseOut=\"hiLite('MBut6','but_6a')\">")
		document.write("<IMG SRC=\"pgfx/but6a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut6\" ALT=\"PAMS Photo Album\"></A></TD>")
	}

// Item 7

	if (urhere==7) {
		document.write("<TD><IMG SRC=\"pgfx/but7d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"contact.html\" onMouseOver=\"hiLite('MBut7','but_7b')\" onMouseDown=\"hiLite('MBut7','but_7c')\" onMouseUp=\"hiLite('MBut7','but_7b')\" onMouseOut=\"hiLite('MBut7','but_7a')\">")
		document.write("<IMG SRC=\"pgfx/but7a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut7\" ALT=\"Contact PAMS\"></A></TD>")
	}
	
// Item 8
		
	if (urhere==8) {
		document.write("<TD><IMG SRC=\"pgfx/but8d.jpg\" WIDTH=80 HEIGHT=26 BORDER=0></TD>")
		}
	else {
		document.write("<TD><A HREF=\"http://www.jingles.com\" onMouseOver=\"hiLite('MBut8','but_8b')\" onMouseDown=\"hiLite('MBut8','but_8c')\" onMouseUp=\"hiLite('MBut8','but_8b')\" onMouseOut=\"hiLite('MBut8','but_8a')\">")
		document.write("<IMG SRC=\"pgfx/but8a.jpg\" WIDTH=80 HEIGHT=26 BORDER=0 NAME=\"MBut8\" ALT=\"JAM Home Page\"></A></TD>")
	}

// End the table

	document.write("</TR></TABLE>")
}

// ----------------------------------------
// Generates code for flash player
// Function passed as "urhere" indicates which button set to grey out
// ----------------------------------------

function player(audiofile) {

  document.write("      <object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0\" width=\"62\" height=\"28\">")
  document.write("        <param name=\"movie\" value=\"" + audiofile + "\" />")
  document.write("        <param name=\"quality\" value=\"high\" />")
  document.write("        <param name=\"wmode\" value=\"transparent\">")
  document.write("        <embed src=\"" + audiofile + "\" quality=\"high\" type=\"application/x-shockwave-flash\" WMODE=\"transparent\" width=\"62\" height=\"28\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" />")
  document.write("      </object>")

}
